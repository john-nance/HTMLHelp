# Advanced Usage

You can link to specific help pages using the URL parameter Action

... pureHelp/default.aspx**?Action=Help__Topic**

Help__Topic is the name of a topic in the help menu - replace spaces with underscores.

The help topic isn't case sensitive so help__topic and Help__TOPIC will also work.

See also [Check Links](javascript:linkTo("Links")) for the utility to check all links in your content.

