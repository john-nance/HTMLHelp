# Using pureHelp

Your help pages should look something like the screen below.

There is a title and logo at the top.

Menu on the left and the help content on the right.

Click any topics in the menu to see more information.

You will also find links in the help content guiding you to other relevent information.

![pureHelp Screenshot](Docs/-images/pureHelp/IntroPage.png)