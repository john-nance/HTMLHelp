# Mobile

You can also use pureHelp on smaller screens.

When there isn't enough room for the help index, it moves into a hamburger menu.

Click the hamburger to show or hide the menu.

![pureHelp Screenshot](Docs/-images/pureHelp/Mobile.png)