# Licensing

This software is provided "as in" with no waranty.

You are free to take this software, use it and adapt as required with no requirement to pay licenses for personal or commercial use.

The source code is licensed under the Mit License.

This software includes other products, in particular this [MarkDown](https://github.com/hey-red/Markdown) library 

